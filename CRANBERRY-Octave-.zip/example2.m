# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    Example 2                                                                #
#                                                                             #
#                                                                             #
# This is a model in the supplementary materials of Arceo, et al (2016):      #
#    ECJ3-G Yeast trehalose system.                                           #
#                                                                             #
# RESULT: The network numbers are as follows:                                 #
#            Species (m): 12                                                  #
#            Complexes (n): 19                                                #
#            Reactant complexes (n_r): 11                                     #
#            Reversible reactions (r_rev): 2                                  #
#            Irreversible reactions (r_irrev): 11                             #
#            Reactions (r): 15                                                #
#            Linkage classes (l): 6                                           #
#            Strong linkage classes (sl): 17                                  #
#            Terminal linkage classes (t): 8                                  #
#            Rank (s): 12                                                     #
#            Reactant rank (q): 9                                             #
#            Deficiency (delta): 1                                            #
#            Reactant deficiency (delta_p): 2                                 #
#                                                                             #
# Reference: Arceo, C.P.A, Jose, E.C., Lao, A.R., and Mendoza, E.R. (2016).   #
#    Reaction networks and kinetics of biochemical systems (supplementary     #
#    materials). Mathematical Biosciences, 283, 13-29. doi:10.1016/j.mbs.     #
#    2016.10.004.                                                             #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 2';
model.species = { }; % do not fill out; will be filled automatically by 'network_numbers'
model.reaction(1) = struct('id', 'A1+A3->A2+A3', 'reactant', struct('species', {'A1', 'A3'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'A2', 'A3'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(2) = struct('id', 'A2+A7->A3+A7', 'reactant', struct('species', {'A2', 'A7'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'A3', 'A7'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(3) = struct('id', 'A3<->A4', 'reactant', struct('species', {'A3'}, 'stoichiometry', {1}), 'product', struct('species', {'A4'}, 'stoichiometry', {1}), 'reversible', true);
model.reaction(4) = struct('id', 'A5<->A5', 'reactant', struct('species', {'A4'}, 'stoichiometry', {1}), 'product', struct('species', {'A5'}, 'stoichiometry', {1}), 'reversible', true);
model.reaction(5) = struct('id', 'A5+A3->A6+A3', 'reactant', struct('species', {'A5', 'A3'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'A6', 'A3'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(6) = struct('id', 'A6+A5+A3->A4+A5+A3', 'reactant', struct('species', {'A6', 'A5', 'A3'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'A4', 'A5', 'A3'}, 'stoichiometry', {1, 1, 1}), 'reversible', false);
model.reaction(7) = struct('id', 'A5+A3+A2->A7+A2', 'reactant', struct('species', {'A5', 'A3', 'A2'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'A7', 'A2'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(8) = struct('id', 'A7->A8', 'reactant', struct('species', {'A7'}, 'stoichiometry', {1}), 'product', struct('species', {'A8'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(9) = struct('id', 'A8->A2', 'reactant', struct('species', {'A8'}, 'stoichiometry', {1}), 'product', struct('species', {'A2'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(10) = struct('id', 'A3->A9', 'reactant', struct('species', {'A3'}, 'stoichiometry', {1}), 'product', struct('species', {'A9'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(11) = struct('id', 'A9->A10', 'reactant', struct('species', {'A9'}, 'stoichiometry', {1}), 'product', struct('species', {'A10'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(12) = struct('id', 'A9->A11', 'reactant', struct('species', {'A9'}, 'stoichiometry', {1}), 'product', struct('species', {'A11'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(13) = struct('id', 'A3->A12', 'reactant', struct('species', {'A3'}, 'stoichiometry', {1}), 'product', struct('species', {'A12'}, 'stoichiometry', {1}), 'reversible', false);

% Generate the network numbers
[model] = network_numbers(model);